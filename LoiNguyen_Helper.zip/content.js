(function() {
    let lastProxyValue = null;
    let lastAgentValue = null;
    let lastProxySet = null;

    setInterval(() => {
        let proxyValue = localStorage.getItem("StopProxy");
        let setProxy = localStorage.getItem("SetProxy");
        let agentValue = localStorage.getItem("UserAgent");

        if (proxyValue !== lastProxyValue) {
            lastProxyValue = proxyValue;
            chrome.runtime.sendMessage({ 
                action: "toggleProxy", 
                enabled: proxyValue !== "true" 
            }, (response) => {
                if (chrome.runtime.lastError) {
                    console.warn("Error sending message:", chrome.runtime.lastError);
                } else {
                    console.log("Response from background:", response);
                }
            });
        }

        if (agentValue !== lastAgentValue) {
            lastAgentValue = agentValue;
            chrome.runtime.sendMessage({ 
                action: "setUserAgent", 
                userAgent: agentValue || "" 
            }, (response) => {
                if (chrome.runtime.lastError) {
                    console.warn("Error sending message:", chrome.runtime.lastError);
                } else {
                    console.log("Response from background:", response);
                }
            });
        }
        
        if (setProxy !== lastProxySet) {
            lastProxySet = setProxy;
            chrome.runtime.sendMessage({ 
                action: "setProxy", 
                proxy: setProxy || ""  // Đổi từ userAgent thành proxy để rõ ràng hơn
            }, (response) => {
                if (chrome.runtime.lastError) {
                    console.warn("Error sending message:", chrome.runtime.lastError);
                } else {
                    console.log("Response from background:", response);
                }
            });
        }
    }, 500);
})();